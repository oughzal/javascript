const userForm=document.forms["userForm"];
const userList = document.getElementById("userList");
const newUser = document.getElementById("newUser");
newUser.onclick = function(e){
    e.preventDefault();
    emptyUser();
}

userForm.onsubmit = function(e){
    e.preventDefault();
    const formData = new FormData(userForm);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200){  
            var reponse =JSON.parse(this.responseText);
            console.log(reponse.success)
            if(reponse.success == true){
                usersList();
                emptyUser(this);
            }
        }
    }
     xhttp.open("POST","/api/?action=save",true);
     xhttp.send(formData);
}

function usersList(){
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200){  
            var reponse =JSON.parse(this.responseText);
            userList.innerHTML="";
             for(item of reponse.data){
                let tr = document.createElement("tr");
                let td = document.createElement("td");
                td.textContent=item.id;
                tr.appendChild(td)
                td = document.createElement("td");
                td.textContent=item.prenom;
                tr.appendChild(td)
                td = document.createElement("td");
                td.textContent=item.nom;
                tr.appendChild(td)
                td = document.createElement("td");
                td.textContent=item.email;
                tr.appendChild(td)
                td = document.createElement("td");
                let btn = document.createElement("i");
                btn.classList.add('btn','btn-primary','fa','fa-edit','edite')
                btn.setAttribute('userID',item.id);
                btn.style.marginRight ="10px"
                btn.style.cursor="pointer"
                btn.onclick = getUser
                td.appendChild(btn);
                btn = document.createElement("i");
                btn.classList.add('btn','btn-primary','fa','fa-trash','delete')
                btn.setAttribute('userID',item.id);
                btn.style.cursor="pointer"
                btn.onclick= deleteUser
                td.appendChild(btn);
                td.classList.add("text-end");
                tr.appendChild(td)
                userList.appendChild(tr)
            }


        }
    }
    xhttp.open("POST","/api/?action=list",true);
    xhttp.send();
}

function editeUser(){
    $id = this.getAttribute('userID')
    console.log("update : " + $id)
    let xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange =function (){
        if(this.readyState==4 && this.status==200){
            var jsonData =JSON.parse(this.responseText);
            console.log(jsonData)
            var reponse = jsonData.data
            userForm.id.value = reponse.id
            userForm.nom.value = reponse.nom 
            userForm.prenom.value = reponse.prenom 
            userForm.email.value = reponse.email 
            userForm.password.value = reponse.password
            userForm.password2.value = reponse.password 
        }
    }
    xhttp.open("GET","/api/?action=edite&id="+$id,true)
    xhttp.send()

}

function deleteUser(){
    if(! confirm("Vous êtes sûre de vouloir surpprimer cet utilisateur")) return false
    id = this.getAttribute('userID')
    console.log("delete : " + id)
    const formData = new FormData();
    formData.append("id",id);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200){ 
             var reponse =JSON.parse(this.responseText);
             console.log(reponse)
            if(reponse.success == true){
                usersList();
            }
        }
    }
     xhttp.open("POST","/api/?action=delete",true);
     xhttp.send(formData);
}

function getUser(){
    id = this.getAttribute('userID')
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200){ 
             var reponse =JSON.parse(this.responseText);
             console.log(reponse)
            if(reponse.success == true){
                data = reponse.data
                userForm.id.value = data.id
                userForm.nom.value = data.nom
                userForm.prenom.value = data.prenom
                userForm.email.value = data.email
                userForm.password.value = data.password
                userForm.password2.value = data.password
            }
        }
    }
     xhttp.open("GET","/api/?action=get&id="+id,true);
     xhttp.send();
}

function emptyUser(){
    // this.ventDefault()
    userForm.id.value = 0
    userForm.nom.value = ""
    userForm.prenom.value = ""
    userForm.email.value = ""
    userForm.password.value = ""
    userForm.password2.value = ""
}

usersList();

function test(){
    const userForm=document.forms["userForm"];
    const formData = new FormData(userForm);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        // traitement du résultat Json
    }
     xhttp.open("POST","/api/?action=save",true);
     xhttp.send(formData);
}