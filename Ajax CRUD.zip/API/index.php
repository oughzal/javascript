<?php
header('Content-Type: application/json; charset=utf-8');
require_once("userController.php");
$userController = new userController();
$response= new stdClass();
$response->status = 200;
$action =(isset($_GET["action"]))? $_GET["action"] :"list";
switch($action){
    case 'list': $response = $userController->usersList();break;
    case 'save' : $response = $userController->updateUser();break;
    case 'get' : $response =$userController->getUser();break;
    case 'delete': $response = $userController->deleteUser();break;
}
echo json_encode($response);
?>