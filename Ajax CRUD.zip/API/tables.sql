-- Active: 1679664683384@@127.0.0.1@3306@mvc
 drop table client;
CREATE Table client(
    `id_client` int PRIMARY KEY AUTO_INCREMENT,
    `cin` VARCHAR(10) UNIQUE,
    `nom` VARCHAR(30),
    `prenom` VARCHAR(30),
    `login` VARCHAR(20),
    `motPass` VARCHAR(200)

);
CREATE table typeHotel(
    id_type int PRIMARY KEY AUTO_INCREMENT,
    nombre_etoiles int 
);

CREATE TABLE hotel(
    id_hotel int PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(200),
    adress VARBINARY(200),
    typeHotel int,
    prix_par_unit DECIMAL(8,2),
    nombre_de_places int,
    Foreign Key (typeHotel) REFERENCES typeHotel(id_type)
    );
create Table reservation(
    id_reserv int PRIMARY key AUTO_INCREMENT,
    id_hotel int,
    id_client int,
    date_debut_sejour DATE,
    date_fin_sejour DATE,
    Foreign Key (id_hotel) REFERENCES hotel(id_hotel),
    Foreign Key (id_client) REFERENCES client(id_client),
    check(date_debut_sejour <= date_fin_sejour)
);

-- Question 1
select * from hotel;

-- Question 4

select r.*,h.`typeHotel` from reservation as r
join hotel h
on r.id_hotel = h.id_hotel
where h.`typeHotel` = 1
;

select h.titre, COUNT(r.id_reserv) as c from hotel h
join reservation r 
on h.id_hotel = r.id_hotel
GROUP BY h.titre
HAVING COUNT(r.*) > 20 
--where h.titre ='A%'
;