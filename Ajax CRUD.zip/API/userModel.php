<?php
class userModel{
    // méthode pour se connecter à la base de données
    private function connect(){
        $db = new mysqli('localhost','root','','javascript');
        if($db->connect_error){
            die('Connect Error : '.$db->connect_error);
            }
        return $db;
    }

    // méthode pour executer des requête : insert, update et delete
    private function executeQuery($sql){
        $db = $this->connect();
        $result = $db->query($sql);
        if($result){
            return true;
        }
        else{
            return false;
        }
    }

    // méthode pour executer des requête : select
    private function fetchQuery($sql){
        $db = $this->connect();
        $result = $db->query($sql);
        $L = [];
        while($row = $result->fetch_object()){
             $L[] = $row;
        }
        $result->free_result();
        $db->close();
        return $L;
    }

    // méthode pour créer un user vide
    private function emptyUser(){
        $user = new stdClass();
        $user->id=0;
        $user->nom="";
        $user->prenom="";
        $user->email="";
        $user->password="";
        return $user;
    }

    // méthode pour ajouter un user
    public function addUser($user){
        $sql = "INSERT INTO 
        user (`nom`,`prenom`,`email`,`password`) 
        VALUES (
            '{$user->nom}',
            '{$user->prenom}',
            '{$user->email}',
            '{$user->password}')";
        return $this->executeQuery($sql);
        
    }

    // méthode mettre à jour un user
    public function updateUser($user){
        $sql ="UPDATE user set 
        `nom` ='{$user->nom}',
        `prenom` ='{$user->prenom}',
        `email` ='{$user->email}',
        `password` ='{$user->password}'
        where id ='{$user->id}'";
        return $this->executeQuery($sql);
    }

    // méthode pour supprimer un user
    public function deleteUser($id){
        $sql ="DELETE from user where id ='{$id}'";
        return $this->executeQuery($sql);
    }

    // méthode pour récuperer un user par son id
    public function getUser($id=0){
        $db = $this->connect();
        $sql ="SELECT * from user where id={$id}";
        $result = $this->fetchQuery($sql);
        if(count($result)>0){
            return $result[0];
        }
        return $this->emptyUser();
    }

    // méthode pour récuperer tous les users
    public function usersList(){
        $sql="SELECT * from user";
        return $this->fetchQuery($sql);
    }

}
?>