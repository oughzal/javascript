<?php
require_once("userModel.php");
class userController{
    private $model;
    private $json;
    public function __construct()
    {
        $this->model = new userModel();
        $this->json = new stdClass();
    }
    public function updateUser(){
        if(isset($_POST["id"])){
            $id =(int)$_POST["id"];
            $user = (object)$_POST;
            if($id==0){
               $this->json->success = $this->model->addUser($user); 
            }
            else{
                $this->json->success = $this->model->updateUser($user);  
            }
            
            
        }
        else{
            $this->json->success = false;
        }
        return $this->json;
    }

    public function usersList(){
       $this->json->data = $this->model->usersList();
       $this->json->success = true;
       return $this->json;
    }

    public function getUser(){
        $id =(isset($_GET["id"]))?(int)$_GET["id"]:0;
        $this->json->data = $this->model->getUser($id);
        $this->json->success = true;
        return $this->json;


    }


    public function deleteUser(){
        $id =(isset($_POST["id"]))?(int)$_POST["id"]:0;
        $this->json->success = $this->model->deleteUser($id);
        return $this->json;
    }


}?>
