-- Active: 1679664683384@@127.0.0.1@3306@javascript
DROP TABLE `user`;
CREATE TABLE user(
    id int PRIMARY KEY AUTO_INCREMENT,
    nom varchar(30),
    prenom varchar(30),
    email varchar(150),
    `password` varchar(25)
  );

  select * from user;
  TRUNCATE user;